using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
namespace LanScope;
public sealed class HeaderMatchSettingsWindow : Window
{
    public CapturePolicy? Result {get;private set;}
    public HeaderMatchSettingsWindow(IcdSchema schema,CapturePolicy? existing)
    {
        Title="공통헤더 · 메시지 식별 규칙";Width=900;Height=850;MinWidth=750;MinHeight=600;Background=new SolidColorBrush(Color.FromRgb(243,246,250));FontSize=13;
        var panel=new StackPanel{Margin=new Thickness(24)};Content=new ScrollViewer{Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        panel.Children.Add(new TextBlock{Text="IP → 헤더 구조 → Length → ICD 크기가 모두 일치하는 패킷만 기록",FontSize=20,FontWeight=FontWeights.SemiBold,TextWrapping=TextWrapping.Wrap});
        panel.Children.Add(new TextBlock{Text="ID와 Length는 직접 선택합니다. 현재 완전한 UDP 데이터그램만 지원하며 TCP 재조립은 하지 않습니다. 체크섬은 없음 모드입니다.",TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray,Margin=new Thickness(0,12,0,18)});
        void Label(string text)=>panel.Children.Add(new TextBlock{Text=text,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,18,0,9)});
        var sourceMode=new ComboBox{ItemsSource=new[]{"현재 ICD에서 헤더 필드 선택","별도 헤더 CSV / C++ 구조체 선택"},SelectedIndex=existing?.SeparateHeader==true||schema.Messages.Length==0?1:0,Padding=new Thickness(10)};Label("1. 헤더 원본");panel.Children.Add(sourceMode);
        var sourceMessage=new ComboBox{Padding=new Thickness(10),Margin=new Thickness(0,10,0,10)};panel.Children.Add(sourceMessage);
        var choose=new Button{Content="별도 헤더 파일 선택 (.csv / .h / .hpp)",Padding=new Thickness(12),ToolTip="CSV 헤더 메시지 또는 C/C++ 헤더 구조체를 선택합니다. includes를 실행하지 않으며 필요한 헤더를 모두 선택하세요."};panel.Children.Add(choose);
        var sourceLabel=new TextBlock{TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray,Margin=new Thickness(0,8,0,0)};panel.Children.Add(sourceLabel);
        var endian=new ComboBox{ItemsSource=new[]{"be","le"},SelectedItem=existing?.ExternalEndian??"be",Width=90};var pack=new ComboBox{ItemsSource=new[]{1,2,4,8},SelectedItem=existing?.ExternalPack??1,Width=70};var bits=new ComboBox{ItemsSource=new[]{"lsb0","msb0"},SelectedItem=existing?.ExternalBitOrder??"lsb0",Width=90};var options=new WrapPanel{Margin=new Thickness(0,12,0,12)};options.Children.Add(new TextBlock{Text="별도 C++: endian / pack / bit order  ",VerticalAlignment=VerticalAlignment.Center});options.Children.Add(endian);options.Children.Add(pack);options.Children.Add(bits);panel.Children.Add(options);
        var external=new Dictionary<string,StructLayoutInfo>();var sources=existing?.HeaderSources.Select(s=>new StructSource(s.Name,[..s.Content])).ToList()??[];
        ComboBox idBox=new ComboBox{DisplayMemberPath="Name",Padding=new Thickness(10)},lengthBox=new ComboBox{DisplayMemberPath="Name",Padding=new Thickness(10)};
        Label("2. header.ID 필드 (raw integer)");panel.Children.Add(idBox);Label("header.Length 필드 (raw integer)");panel.Children.Add(lengthBox);
        Label("헤더 전체 크기 (bytes) · 구조체 크기로 초기화하며 직접 변경 가능");var headerBytes=new TextBox{Text=(existing?.HeaderBytes??0).ToString(),Padding=new Thickness(10)};panel.Children.Add(headerBytes);
        panel.Children.Add(new TextBlock{Text="모든 새 메시지는 지정한 공통헤더 전체 크기를 포함해야 합니다. 타입명·멤버명은 고정하지 않으며, 선택한 ID/Length 위치와 비트 폭으로 검사합니다.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,18,0,8)});
        var lengthIncludes=new CheckBox{Content="header.Length 값이 공통헤더를 포함한 전체 UDP payload 크기",IsChecked=existing?.LengthIncludesHeader??true,Margin=new Thickness(0,8,0,8)};panel.Children.Add(lengthIncludes);
        panel.Children.Add(new TextBlock{Text="해제하면 Length + 헤더 크기 = 실제 UDP payload 크기를 검사합니다. 모든 메시지는 지정 헤더 전체 크기 이상이며 ID·Length 위치·비트 폭·엔디언이 일치해야 합니다. 필드 이름은 자유입니다.",TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray});
        Label("3. 전체 ICD 자동 검사");
        panel.Children.Add(new TextBlock{Text="공통헤더는 메시지 없이 먼저 저장할 수 있습니다. 이후 MessageHeader Header;처럼 타입 이름으로 재사용합니다. 메시지와 필드 이름은 자유입니다. 선택한 ID·Length의 위치·비트 폭·엔디언과 지정한 헤더 전체 크기를 모든 메시지에서 확인합니다. 실제 ID 숫자는 제한하지 않습니다.",TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray});
        var status=new TextBlock{TextWrapping=TextWrapping.Wrap,Foreground=Brushes.DarkRed,Margin=new Thickness(0,10,0,12)};panel.Children.Add(status);
        var save=new Button{Content="공통헤더 형식 저장",Padding=new Thickness(14),ToolTip="헤더 필드와 대상 ICD를 대조하고 구조·길이·엔디언을 검증합니다. 공통헤더 형식과 원본은 즉시 암호화 저장해 다른 메시지에서 이름으로 재사용합니다. 메시지 변경은 프로파일을 별도로 저장하세요."};panel.Children.Add(save);
        void LoadExternal(){external.Clear();if(sources.Count==0)return;if(sources.Count==1&&sources[0].Name.EndsWith(".csv",StringComparison.OrdinalIgnoreCase)){var hs=IcdCsv.Parse(sources[0].Content);foreach(var m in hs.Messages)external[m]=new(m,hs.RequiredBytes(m),1,hs.Fields.Where(f=>f.Message==m).ToArray());}else foreach(var pair in CStructParser.Parse(sources,(int)pack.SelectedItem,(string)endian.SelectedItem,(string)bits.SelectedItem))external[pair.Key]=pair.Value;}
        IReadOnlyList<IcdField> Fields(){if(sourceMessage.SelectedItem is not string m)return [];return sourceMode.SelectedIndex==1?external.GetValueOrDefault(m)?.Fields??[]:schema.Fields.Where(f=>f.Message==m).ToArray();}
        void UpdateFields(){var fields=Fields().Where(f=>f.Type is "uint" or "int" &&f.Scale==1&&f.Bias==0&&f.BitLength<=64).ToList();idBox.ItemsSource=fields;lengthBox.ItemsSource=fields;idBox.SelectedItem=fields.FirstOrDefault(f=>existing?.IdField?.Name==f.Name)??fields.FirstOrDefault(f=>f.Name.Split('.').Last().Equals("id",StringComparison.OrdinalIgnoreCase));lengthBox.SelectedItem=fields.FirstOrDefault(f=>existing?.LengthField?.Name==f.Name)??fields.FirstOrDefault(f=>f.Name.Split('.').Last().Equals("length",StringComparison.OrdinalIgnoreCase));if(sourceMode.SelectedIndex==1&&sourceMessage.SelectedItem is string m&&external.TryGetValue(m,out var layout))headerBytes.Text=layout.Size.ToString();}
        void UpdateSource(){headerBytes.IsReadOnly=false;options.IsEnabled=sourceMode.SelectedIndex==1;choose.IsEnabled=sourceMode.SelectedIndex==1;sourceLabel.Text=sourceMode.SelectedIndex==1?string.Join(", ",sources.Select(s=>s.Name)):"현재 ICD의 메시지에서 ID·Length를 선택하세요.";sourceMessage.ItemsSource=sourceMode.SelectedIndex==1?external.Keys.ToArray():schema.Messages;sourceMessage.SelectedItem=existing?.HeaderName;if(sourceMessage.SelectedItem==null)sourceMessage.SelectedIndex=0;UpdateFields();}
        choose.Click+=(_,_)=>{var d=new OpenFileDialog{Filter="헤더 CSV/C++|*.csv;*.h;*.hpp",Multiselect=true};if(d.ShowDialog(this)!=true)return;try{if(d.FileNames.Length>128||d.FileNames.Sum(f=>new FileInfo(f).Length)>16*1024*1024)throw new ArgumentException("헤더 합계 최대 16 MB / 128개입니다.");sources=d.FileNames.Select(f=>new StructSource(Path.GetFileName(f),File.ReadAllBytes(f))).ToList();LoadExternal();UpdateSource();}catch(Exception e){status.Text=e.Message;}};
        foreach(var box in new[]{endian,pack,bits})box.SelectionChanged+=(_,_)=>{try{LoadExternal();UpdateSource();}catch(Exception e){status.Text=e.Message;}};
        sourceMode.SelectionChanged+=(_,_)=>UpdateSource();sourceMessage.SelectionChanged+=(_,_)=>UpdateFields();
        CapturePolicy Build(){if(idBox.SelectedItem is not IcdField id||lengthBox.SelectedItem is not IcdField length)throw new ArgumentException("ID와 Length 필드를 각각 선택하세요.");var policy=new CapturePolicy{RequireHeaderLayout=true,MatchByStructure=true,IdField=id,LengthField=length,HeaderName=sourceMessage.SelectedItem as string??"",SeparateHeader=sourceMode.SelectedIndex==1,HeaderSources=sourceMode.SelectedIndex==1?sources:[],IcdIncludesHeader=true,LengthIncludesHeader=lengthIncludes.IsChecked==true,HeaderBytes=int.Parse(headerBytes.Text),ExternalPack=(int)pack.SelectedItem,ExternalEndian=(string)endian.SelectedItem,ExternalBitOrder=(string)bits.SelectedItem,HeaderFields=sourceMode.SelectedIndex==1?Fields().Select(f=>f with{Description="",Unit="",SourceLine=0}).ToList():[id,length],Messages=[]};policy.ValidateHeaderDefinition();return policy;}
        var check=new Button{Content="현재 메시지의 헤더 검증",Padding=new Thickness(12),Margin=new Thickness(0,8,0,12),ToolTip="공통헤더를 저장하지 않고 메시지별 ID·Length 위치·비트 폭과 헤더 전체 크기를 확인합니다."};panel.Children.Insert(panel.Children.IndexOf(status),check);
        check.Click+=(_,_)=>{try{var policy=Build();status.Text=schema.Messages.Length==0?"현재 메시지 없음 · 헤더 형식을 먼저 저장할 수 있습니다.":string.Join("\n",schema.Messages.Select(m=>{var error=policy.HeaderError(schema,m);return error.Length==0?m+": 정상":error;}));}catch(Exception error){status.Text=error.Message;}};
        save.Click+=(_,_)=>{try{var policy=Build();if(schema.Messages.Length>0){try{policy.Prepare(schema);}catch(ArgumentException){policy.Messages=[];}}Result=policy;DialogResult=true;}catch(Exception e){status.Text=e.Message;}};
        try{LoadExternal();UpdateSource();}catch(Exception e){status.Text=e.Message;}
    }
}
